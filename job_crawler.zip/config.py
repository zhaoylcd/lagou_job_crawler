#-*- coding:utf-8 -*-
__author__ = 'liang'

redis_host = 'localhost'
redis_port = 6379

mongo_host = 'localhost'
mongo_port = 27017

mongo_db = 'zhaopin'
mongo_table = 'job_positions'

